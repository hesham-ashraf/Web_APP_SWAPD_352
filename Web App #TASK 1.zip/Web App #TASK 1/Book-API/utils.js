function findBookById(books, id) {
    return books.find(book => book.id === id);
}


function updateBook(books, id, updatedData) {
    const book = findBookById(books, id);
    if (book) {
        book.title = updatedData.title || book.title;
        book.author = updatedData.author || book.author;
        return true;
    }
    return false;
}

module.exports = { findBookById, updateBook };

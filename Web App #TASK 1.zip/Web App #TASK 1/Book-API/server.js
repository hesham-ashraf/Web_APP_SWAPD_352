    const express = require('express');
    const { findBookById, updateBook } = require('./utils');
    const app = express();
    const port = 3000;

// middleware 
    app.use(express.json());


    let books = [
        { id: 1, title: 'The Catcher in the Rye', author: 'J.D. Salinger' },
        { id: 2, title: 'ahmed', author: 'hesham ashraf ' },
        { id: 3, title: 'EYE', author: 'ahmed mohamed '}

    ];

    app.get('/books', (req, res) => {
        res.json(books);
    });


    app.post('/books', (req, res) => {
        const { title, author } = req.body;
        const newBook = {
            id: books.length + 1,
            title,
            author
        };
        books.push(newBook);
        res.status(201).json(newBook);
    });


    app.get('/books/:id', (req, res) => {
        const book = findBookById(books, parseInt(req.params.id));
        if (!book) {
            return res.status(404).send('Book not found');
        }
        res.json(book);
    });


    app.put('/books/:id', (req, res) => {
        const updatedData = req.body;
        const success = updateBook(books, parseInt(req.params.id), updatedData);
        if (!success) return res.status(404).send('Book not found');
        
        res.json({ message: 'Book updated successfully' });
    });

    
    app.delete('/books/:id', (req, res) => {
        const bookIndex = books.findIndex(book => book.id === parseInt(req.params.id));
        
        if (bookIndex === -1) {
            return res.status(404).send('Book not found');
        }
    
        books.splice(bookIndex, 1);
        res.json({ message: 'Book deleted successfully' });
    });
    


    app.listen(port, () => {
        console.log(`Server is running on http://localhost:${port}`);
    });

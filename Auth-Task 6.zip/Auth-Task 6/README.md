
# Express.js Authentication and Authorization API

This is a simple **Express.js API** that implements **JWT-based authentication**, **role-based access control (RBAC)**, **password reset functionality**, and **refresh tokens**. It uses **lowdb** for lightweight user storage and provides secure authentication for users with various roles.

## Setup Instructions

### Prerequisites

1. **Node.js**: Ensure you have [Node.js](https://nodejs.org/en/) installed on your machine.
2. **NPM**: This comes with Node.js, but ensure it's up to date.

### 1. Install dependencies

Run the following command to install the required dependencies:

```bash
npm install
```

### 2. Set up environment variables

Create a `.env` file in the root directory and add the following environment variables:

```plaintext
PORT=5000
JWT_SECRET=your-secret-key
EMAIL_USER=your-email@gmail.com  # Your email address for password reset
EMAIL_PASSWORD=your-email-password  # Your email password
BASE_URL=http://localhost:5000
```

Make sure to replace `your-secret-key` with a strong secret key for JWT, and provide your email credentials for password reset functionality.

### 3. Start the server

To start the API server, run the following command:

```bash
npm start
```

The server will start running at `http://localhost:5000`.

---

## Features Implemented

### 1. **User Registration and Login**

- **User Registration (`POST /api/register`)**:
  - Fields: `username`, `email`, `password`, `role`
  - Validates email format and enforces strong password rules (min 8 characters, 1 number, 1 special character).
  - Hashes the password before storing it in the database (lowdb).
  - Issues a **JWT token** upon successful registration.

- **User Login (`POST /api/login`)**:
  - Validates the user's email and password.
  - Issues a **JWT token** valid for 1 hour upon successful login.

### 2. **JWT Authentication and Role-Based Authorization**

- **JWT Authentication**: Protects routes by verifying the token passed in the `Authorization` header.
- **Role-Based Access Control**: Supports three roles:
  - `user`
  - `moderator`
  - `admin`
  - Routes are protected based on roles.

### 3. **Role-Based Routes**

- **Public Route (`GET /api/public`)**: Accessible by everyone.
- **Protected Route (`GET /api/protected`)**: Accessible by authenticated users only.
- **Moderator Route (`GET /api/moderator`)**: Accessible by `moderator` and `admin` roles.
- **Admin Route (`GET /api/admin`)**: Accessible by `admin` role only.

### 4. **User Profile and Role Management**

- **Get User Profile (`GET /api/profile`)**: Returns the profile information of the authenticated user.
- **Update Profile (`PUT /api/profile`)**: Allows users to update their email and password.
- **Update User Role (`PUT /api/users/:id/role`)**: Allows an `admin` user to update another user's role.

### 5. **Security Enhancements**

- **Rate Limiting**: Limits the number of requests to the login and registration routes to prevent brute-force attacks.
- **Password Hashing**: Passwords are hashed before storing them using **bcryptjs**.
- **Token Expiration**: JWT tokens expire after 1 hour, and expired tokens are handled with appropriate error messages.
- **Error Handling**: All errors are handled securely without exposing internal details.

### 6. **Bonus Features**

- **Refresh Tokens**: Provides **refresh tokens** that allow users to get a new access token after expiration, stored in **HttpOnly cookies**.
- **Password Reset Flow**:
  - **Request Password Reset (`POST /api/password-reset`)**: Sends a reset link to the user’s email.
  - **Reset Password (`POST /api/reset-password`)**: Allows users to reset their password using the reset token.

### 7. **User Storage in a JSON File**

- **Lowdb** is used to store user data in a lightweight JSON file (`db.json`).

---

## How to Test Each Endpoint

### 1. **Register User**

- **Endpoint**: `POST /api/register`
- **Request Body**:
  ```json
  {
    "username": "johnDoe",
    "email": "john@example.com",
    "password": "Password123!",
    "role": "user"
  }
  ```
- **Response**:
  - `201 Created`: Success
  - `400 Bad Request`: If email is already in use or validation fails

### 2. **Login User**

- **Endpoint**: `POST /api/login`
- **Request Body**:
  ```json
  {
    "email": "john@example.com",
    "password": "Password123!"
  }
  ```
- **Response**:
  - `200 OK`: Returns the JWT access token
  - `401 Unauthorized`: If credentials are invalid

### 3. **Public Route (No Authentication)**

- **Endpoint**: `GET /api/public`
- **Response**:
  - `200 OK`: Public message

### 4. **Protected Route (JWT Required)**

- **Endpoint**: `GET /api/protected`
- **Request**: Pass the JWT token in the `Authorization` header:
  ```plaintext
  Authorization: Bearer <your-jwt-token>
  ```
- **Response**:
  - `200 OK`: Returns the authenticated user's information
  - `401 Unauthorized`: If no token is provided
  - `403 Forbidden`: If token is expired or invalid

### 5. **Moderator Route (Role-Based)**

- **Endpoint**: `GET /api/moderator`
- **Request**: Pass the JWT token in the `Authorization` header (role must be `moderator` or `admin`).
- **Response**:
  - `200 OK`: Returns message for moderators and admins
  - `403 Forbidden`: If the role is not `moderator` or `admin`

### 6. **Admin Route (Role-Based)**

- **Endpoint**: `GET /api/admin`
- **Request**: Pass the JWT token in the `Authorization` header (role must be `admin`).
- **Response**:
  - `200 OK`: Returns message for admins
  - `403 Forbidden`: If the role is not `admin`

### 7. **User Profile**

- **Endpoint**: `GET /api/profile`
- **Request**: Pass the JWT token in the `Authorization` header.
- **Response**:
  - `200 OK`: Returns the authenticated user's profile data

### 8. **Update Profile**

- **Endpoint**: `PUT /api/profile`
- **Request Body**:
  ```json
  {
    "email": "newemail@example.com",
    "password": "NewPassword123!"
  }
  ```
- **Request**: Pass the JWT token in the `Authorization` header.
- **Response**:
  - `200 OK`: Profile updated successfully

### 9. **Admin Update User Role**

- **Endpoint**: `PUT /api/users/:id/role`
- **Request Body**:
  ```json
  {
    "role": "admin"
  }
  ```
- **Request**: Pass the JWT token in the `Authorization` header (must be `admin` role).
- **Response**:
  - `200 OK`: User's role updated

### 10. **Password Reset Request**

- **Endpoint**: `POST /api/password-reset`
- **Request Body**:
  ```json
  {
    "email": "john@example.com"
  }
  ```
- **Response**:
  - `200 OK`: Password reset email sent
  - `404 Not Found`: If the email does not exist in the system

### 11. **Reset Password**

- **Endpoint**: `POST /api/reset-password`
- **Request Body**:
  ```json
  {
    "resetToken": "<reset-token>",
    "newPassword": "NewPassword123!"
  }
  ```
- **Response**:
  - `200 OK`: Password successfully reset
  - `400 Bad Request`: If the reset token is invalid or expired

---

## Conclusion

This API provides a robust authentication and authorization system with JWT, refresh tokens, and role-based access control. It allows for secure user registration, login, and profile management, while also offering password reset functionality.

---

const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const { load } = require('./db'); // Import the load function
const rateLimit = require('express-rate-limit');
const app = express();

dotenv.config();


// Rate Limiting
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // Limit each IP to 5 requests per windowMs
    message: "Too many requests, please try again later."
});


app.use(express.json()); 
app.use(cors()); 

app.use('/api/register', limiter);
app.use('/api/login', limiter);

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);  
    res.status(500).json({ message: 'Something went wrong, please try again later.' });
});


// Load the database on startup
load().then(() => {
    console.log('Database loaded successfully');
}).catch(err => {
    console.error('Error loading database:', err);
});


const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/user');

app.use('/api', authRoutes);
app.use('/api', userRoutes);

const port = process.env.PORT || 5000;
app.listen(port, () => console.log(`Server running on port ${port}`));

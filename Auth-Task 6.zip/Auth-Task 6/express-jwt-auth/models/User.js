let users = []; // In-memory users list

class User {
    constructor({ username, email, password, role }) {
        this.username = username;
        this.email = email;
        this.password = password;
        this.role = role;
    }

    static async save() {
        users.push(this);
    }

    static async findByEmail(email) {
        return users.find(user => user.email === email);
    }
}

module.exports = User;

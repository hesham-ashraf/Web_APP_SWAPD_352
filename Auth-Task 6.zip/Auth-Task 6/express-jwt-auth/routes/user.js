const express = require('express');
const router = express.Router();
const { authenticateToken, authorizeRole } = require('../middleware/auth');

// Public Route (No authentication required)
router.get('/public', (req, res) => {
    res.json({ message: 'This is a public route' });
});

// Protected Route (Authentication required)
router.get('/protected', authenticateToken, (req, res) => {
    res.json({ message: `Hello, ${req.user.userId}` });
});

// Moderator-Only Route
router.get('/moderator', authenticateToken, authorizeRole(['moderator', 'admin']), (req, res) => {
    res.json({ message: 'This is a moderator route' });
});

// Admin-Only Route
router.get('/admin', authenticateToken, authorizeRole(['admin']), (req, res) => {
    res.json({ message: 'This is an admin route' });
});


// Admin-Only: Update User Role
router.put('/users/:id/role', authenticateToken, authorizeRole(['admin']), async (req, res) => {
    const { role } = req.body;
    const updatedUser = await User.updateRole(req.params.id, role);
    res.json(updatedUser);
});




// View Profile
router.get('/profile', authenticateToken, (req, res) => {
    const user = User.findByEmail(req.user.userId); // Assume a method to get user info by ID
    res.json(user);
});

// Update Profile
router.put('/profile', authenticateToken, async (req, res) => {
    const { email, password } = req.body;
    const hashedPassword = password ? await bcrypt.hash(password, 10) : undefined;

    const updatedUser = await User.update(req.user.userId, { email, password: hashedPassword });
    res.json(updatedUser);
});




module.exports = router;
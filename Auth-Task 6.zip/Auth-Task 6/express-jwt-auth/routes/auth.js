const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

// Register Route
router.post('/register', authController.registerUser);

// Login Route
router.post('/login', authController.loginUser);

// Refresh token route
router.post('/refresh-token', authController.refreshToken);

// Password reset request route
router.post('/password-reset', authController.requestPasswordReset);

// Reset password route
router.post('/reset-password', authController.resetPassword);


module.exports = router;

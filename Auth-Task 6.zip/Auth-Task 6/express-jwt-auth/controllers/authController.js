const nodemailer = require('nodemailer');
const crypto = require('crypto');   
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User'); // Assume you have a simple user model.


// Register a new user
exports.registerUser = [
    body('email').isEmail().withMessage('Please enter a valid email address'),
    body('password')
        .isLength({ min: 8 })
        .withMessage('Password must be at least 8 characters long')
        .matches(/\d/)
        .withMessage('Password must contain at least one number')
        .matches(/[!@#$%^&*(),.?":{}|<>]/)
        .withMessage('Password must contain at least one special character'),
    body('role').isIn(['user', 'moderator', 'admin']).withMessage('Role must be one of "user", "moderator", or "admin"'),

    // Handle registration logic
    async (req, res) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        const { username, email, password, role } = req.body;

        // Check if the email already exists
        const userExists = db.data.users.find(user => user.email === email);
        if (userExists) {
            return res.status(400).json({ message: 'Email is already in use' });
        }

        // Hash the password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create the new user
        const newUser = { username, email, password: hashedPassword, role };
        db.data.users.push(newUser);  

        await save();

        res.status(201).json({ message: 'User registered successfully' });
    }
];


exports.loginUser = async (req, res) => {
    const { email, password } = req.body;

    const user = await User.findByEmail(email); 

    if (!user || !(await bcrypt.compare(password, user.password))) {
        return res.status(401).json({ message: 'Invalid credentials' });
    }

    // Generate an access token (expires in 1 hour)
    const accessToken = jwt.sign(
        { userId: user.email, role: user.role },
        process.env.JWT_SECRET,
        { expiresIn: '1h' }
    );

    // Generate a refresh token (expires in 7 days)
    const refreshToken = jwt.sign(
        { userId: user.email, role: user.role },
        process.env.JWT_SECRET,
        { expiresIn: '7d' }
    );

    // Store refresh token in the response as an HttpOnly cookie
    res.cookie('refresh_token', refreshToken, {
        httpOnly: true, 
        secure: process.env.NODE_ENV === 'production',  
        maxAge: 7 * 24 * 60 * 60 * 1000  // Refresh token is valid for 7 days
    });

    // Send the access token in the response body
    res.json({ accessToken });
};

exports.refreshToken = (req, res) => {
    const refreshToken = req.cookies.refresh_token;

    if (!refreshToken) {
        return res.status(401).json({ message: 'No refresh token provided' });
    }

    // Verify refresh token
    jwt.verify(refreshToken, process.env.JWT_SECRET, (err, decoded) => {
        if (err) {
            return res.status(403).json({ message: 'Invalid or expired refresh token' });
        }

        // Generate a new access token
        const accessToken = jwt.sign(
            { userId: decoded.userId, role: decoded.role },
            process.env.JWT_SECRET,
            { expiresIn: '1h' }
        );

        res.json({ accessToken });
    });
};

// Email setup using Nodemailer
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASSWORD
    }
});

// Generate a reset token and send it to the user via email
exports.requestPasswordReset = async (req, res) => {
    const { email } = req.body;
    const user = db.data.users.find(user => user.email === email);

    if (!user) {
        return res.status(404).json({ message: 'User not found' });
    }

    // Generate a reset token
    const resetToken = crypto.randomBytes(20).toString('hex');
    user.resetToken = resetToken;
    user.resetTokenExpiry = Date.now() + 3600000; // Token expires in 1 hour

    // Save the updated user data
    await save();

    // Send the reset link via email
    const resetLink = `${process.env.BASE_URL}/reset-password/${resetToken}`;

    const mailOptions = {
        from: process.env.EMAIL_USER,
        to: user.email,
        subject: 'Password Reset',
        text: `You requested a password reset. Please click the following link to reset your password: ${resetLink}`
    };

    transporter.sendMail(mailOptions, (err, info) => {
        if (err) {
            return res.status(500).json({ message: 'Error sending email' });
        }
        res.json({ message: 'Password reset link sent to your email' });
    });
};

exports.resetPassword = async (req, res) => {
    const { resetToken, newPassword } = req.body;

    // Find the user by reset token
    const user = db.data.users.find(user => user.resetToken === resetToken && user.resetTokenExpiry > Date.now());

    if (!user) {
        return res.status(400).json({ message: 'Invalid or expired reset token' });
    }

    // Hash the new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    user.password = hashedPassword;
    user.resetToken = undefined;  
    user.resetTokenExpiry = undefined;  

    await save();

    res.json({ message: 'Password successfully updated' });
};
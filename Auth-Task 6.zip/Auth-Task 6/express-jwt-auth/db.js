const { Low, JSONFile } = require('lowdb');
const path = require('path');

const db = new Low(new JSONFile(path.join(__dirname, 'db.json')));

db.data = {
    users: []
};

async function save() {
    await db.write();
}

// Load the database on startup
async function load() {
    await db.read();
}

module.exports = { db, save, load };
